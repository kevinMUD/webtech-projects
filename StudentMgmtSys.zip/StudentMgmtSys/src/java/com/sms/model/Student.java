/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sms.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;


/**
 *
 * @author hnjej
 */
@Entity
public class Student implements Serializable{
    @Id
    private String regNo;
    private String fistName;
    private String lastName;
    private Date dob;

    public Student() {
    }

    public Student(String regNo, String fistName, String lastName, Date dob) {
        this.regNo = regNo;
        this.fistName = fistName;
        this.lastName = lastName;
        this.dob = dob;
    }
         
    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getFistName() {
        return fistName;
    }

    public void setFistName(String fistName) {
        this.fistName = fistName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }
    
    
    
}
