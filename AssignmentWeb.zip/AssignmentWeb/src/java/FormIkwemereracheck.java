

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet(urlPatterns = {"/FormIkwemereracheck"})
public class FormIkwemereracheck extends HttpServlet {

    
   
     Connection con;
    PreparedStatement pst;
    

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       try {
            String phone = request.getParameter("Phone");
            String Address = request.getParameter("Address");
            String Age = request.getParameter("Age");
            String Email = request.getParameter("Email");
            String Password = request.getParameter("Password");
            String ComfirmPassword = request.getParameter("comfirmPassword");
            String names = request.getParameter("names");
            String status = request.getParameter("status");

            Part firstfiles = request.getPart("firstfiles");
            InputStream fisfile = firstfiles.getInputStream();

            Part secondfiles = request.getPart("secondfiles");
            InputStream secondfile = secondfiles.getInputStream();

            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.socketFactory.port", "465");
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "465");

            Session session = Session.getInstance(props,
                    new javax.mail.Authenticator() {
                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication("mukakadays@gmail.com", "gnqwxnoxhajiivfd");
                        }
                    });

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/campus", "root", "");
            pst = con.prepareStatement("insert into auca(phone, Address, Age, Email, Password, comfirmPassword, names, status, firstfiles, secondfiles) values('" + phone + "','" + Address + "','" + Age + "','" + Email + "','" + Password + "','" + ComfirmPassword + "','" + names + "','" + status + "','" + fisfile + "','" + secondfile + "')");
            int result = pst.executeUpdate();
            if (result == 1) {
                response.sendRedirect("wabikoze.jsp");
                pst = con.prepareStatement(" select * from signup where Email='" + Email + "'");
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {

                    String email = rs.getString("Email");
                    if (email.equals(Email)) {
                        Message message = new MimeMessage(session);
                        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
                        message.setSubject("Welcame");
                        message.setText("You Registered Success");
                        Transport.send(message);
                        System.out.println("Succesfully Email sent..!!!!");
                    } else {
                        response.sendRedirect("FormIKwemerera.jsp");
                    }
                }
            }

        } catch (ClassNotFoundException | SQLException | MessagingException ex) {
            Logger.getLogger(WebTec.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
 

}

