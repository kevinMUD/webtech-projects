

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/Connectioncheck"})
public class Connectioncheck extends HttpServlet {

   
   
        Connection con;
    PreparedStatement pst;

   

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
     try {
            String emails = request.getParameter("email");
            String passwords = request.getParameter("passwd");
            
            
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/campus","root","");
            pst=con.prepareStatement(" select * from signtable where Email='"+emails+"'  and  Passwords='"+passwords+"'");
            ResultSet rs=pst.executeQuery();
            while(rs.next()){
                
                String email=rs.getString("Email");
                String passrd=rs.getString("Passwords");
                
                if(email.equals(emails)){
                    response.sendRedirect("Sincrine.jsp");
                }else{
                  response.sendRedirect("Connection.jsp");
                }
                    
            }
                    
                    
                    
                
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Logincheck.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        

    }
}
