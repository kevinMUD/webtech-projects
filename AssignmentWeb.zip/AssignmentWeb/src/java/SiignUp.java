

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/SiignUp"})
public class SiignUp extends HttpServlet {

   
    
     Connection con;
    PreparedStatement pst;

    
    

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       try {
            String emails = request.getParameter("email");
            String passwords = request.getParameter("passwd");
             String Confirmpassword = request.getParameter("passwd");
            
            
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/campus","root","");
             pst = con.prepareStatement("insert into signtable(Email, Passwords, comfirmPassword) values('" + emails + "','" +  passwords + "','" + Confirmpassword+ "')");
            
           
                
                
                if(passwords.equals(Confirmpassword)){
                    
                     pst.executeUpdate();
                     response.sendRedirect("index.jsp");
                }else{
                  response.sendRedirect("SiignUp.jsp");
                  
                }
                    
            }
                    
                    
                    
         catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Logincheck.class.getName()).log(Level.SEVERE, null, ex);
        }

}

}
