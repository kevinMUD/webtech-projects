package com.team2.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryMSApplication {
	public static void main(String[] args) {
		SpringApplication.run(InventoryMSApplication.class, args);
	}
}
