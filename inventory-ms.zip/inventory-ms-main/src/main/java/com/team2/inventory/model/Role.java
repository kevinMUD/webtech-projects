package com.team2.inventory.model;

public enum Role {
    ADMIN
}