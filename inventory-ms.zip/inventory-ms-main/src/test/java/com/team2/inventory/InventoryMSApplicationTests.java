package com.team2.inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryMSApplicationTests {

	@Test
	void contextLoads() {
	}

}
